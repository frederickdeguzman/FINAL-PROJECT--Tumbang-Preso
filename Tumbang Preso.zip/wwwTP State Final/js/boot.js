
bootGame = {

		create:function(){
				game.physics.startSystem(Phaser.Physics.ARCADE);
			
				game.state.start("preloadGame");
				keyboard = game.input.keyboard.createCursorKeys();
		}
}

preloadGame = {
	preload: function(){

		game.load.spritesheet('Slip', 'assets/images/Slipper.png',120,120);
		game.load.spritesheet('Lata', 'assets/images/Can.png',120,120);
		game.load.spritesheet('pauseButton','assets/images/pause1.png',62,68);

    	game.load.image('hoop', 'assets/images/inside.png');
		game.load.image('side rim', 'assets/images/side_rim.png');
		game.load.image('front rim', 'assets/images/front_rim.png');
		game.load.image('home', 'assets/images/Home1.png');
		game.load.image('play', 'assets/images/PlayBtn.png');
		game.load.image('win0', 'assets/images/panalo1.png');
		game.load.image('win1', 'assets/images/panalo2.png');
		game.load.image('win2', 'assets/images/panalo3.png');
		game.load.image('win3', 'assets/images/win3.png');
		game.load.image('win4', 'assets/images/win4.png');
		game.load.image('lose0', 'assets/images/images1.png');
		game.load.image('lose1', 'assets/images/images2.png');
		game.load.image('lose2', 'assets/images/images3.png');
		game.load.image('PrevBtn', 'assets/images/PrevBtn.png');
		game.load.image('about', 'assets/images/About.png');
		game.load.image('AboutBtn', 'assets/images/AboutBtn.png');
		game.load.image('A', 'assets/images/Artificial.png');
		game.load.image('platform', 'assets/images/Platform.png');

		game.load.audio('score', 'assets/audio/win.wav');
		game.load.audio('whoosh', 'assets/audio/release.wav');
		game.load.audio('fail', 'assets/audio/fail.wav');
		game.load.audio('spawn', 'assets/audio/appear.wav');

	},

	create:function(){
		game.state.start("menuGame");
	}
}

menuGame = {
	create:function(){

		game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
    	game.scale.forcePortrait = true;
    	game.scale.forceLandscape = false;
    	game.scale.pageAlignVertically = true;
		game.scale.pageAlignHorizontally = true;
		game.scale.setScreenSize = true;
		game.scale.refresh();
		
		home = game.add.image(0,0,'home');
		home.scale.set(1.4);
		pbtn = game.add.button(w/2,425,"play",this.lundag);
		pbtn.anchor.set(0.5);
    	pbtn.scale.x = 1.4;
    	pbtn.scale.y = 1.4;

    	abtn = game.add.button(w/2,530,"AboutBtn",this.aboutp);
		abtn.anchor.set(0.5);
    	abtn.scale.x = 1.4;
    	abtn.scale.y = 1.4;

		console.log("current state: menu");

	},
	update:function(){
			if(keyboard.up.isDown){
				
			}
	},
	lundag:function (){
		game.state.start("playGame");
   },
   aboutp:function (){
		about = game.add.image(0,0,'about');
		about.scale.x = 1.4;
		about.scale.y = 1.3;

		prevbtn = game.add.button(40,40,"PrevBtn",prevf);
		prevbtn.anchor.set(0.5);
    	prevbtn.scale.x = 0.3;
    	prevbtn.scale.y = 0.3;

    	function prevf() {
        	prevbtn.visible =! prevbtn.visible;
        	prevbtn.destroy();


       		 window.location.href=window.location.href;
            }
   },
  
}

playGame = {

	create: function(){
		console.log("current state: play");
		game.physics.startSystem(Phaser.Physics.P2JS);
		game.physics.p2.setImpactEvents(true);

		game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
    	game.scale.forcePortrait = true;
    	game.scale.forceLandscape = false;
    	game.scale.pageAlignVertically = true;
		game.scale.pageAlignHorizontally = true;
		game.scale.setScreenSize = true;
		game.scale.refresh();

		platform1 = game.add.sprite(0, 200, 'platform');
		//game.physics.enable(platform1, Phaser.Physics.ARCADE);
		game.physics.arcade.enable(platform1);
		platform1.body.immovable = true;
		platform1.enableBody = true;
		//platform1.anchor.setTo(0.5, 0.5);
		platform1.scale.x = 0.3;
		platform1.scale.y = 0.5;
		//platform1.body.velocity = 100;

		platform2 = game.add.sprite(388, 200, 'platform');
		//game.physics.enable(platform2, Phaser.Physics.ARCADE);
		game.physics.arcade.enable(platform2);
		platform2.body.immovable = true;
		platform2.enableBody = true;
		//platform2.anchor.setTo(0.5, 0.5);
		platform2.scale.x = 0.3;
		platform2.scale.y = 0.5;

		platform3 = game.add.sprite(w/2, 200, 'platform');
		//game.physics.enable(platform3, Phaser.Physics.ARCADE);
		game.physics.arcade.enable(platform3);
		platform3.body.immovable = true;
		platform3.enableBody = true;
		platform3.anchor.setTo(0.5, 0.5);
		platform3.scale.x = 0.3;
		platform3.scale.y = 0.5;

		prevbtn = game.add.button(40,40,"PrevBtn",prevf);
		prevbtn.anchor.set(0.5);
    	prevbtn.scale.x = 0.3;
    	prevbtn.scale.y = 0.3;

    	function prevf() {
        	game.state.start("menuGame");
            }

		collisionGroup = game.physics.p2.createCollisionGroup();
		
		score_sound = game.add.audio('score');
		backboard = game.add.audio('backboard');
		whoosh = game.add.audio('whoosh');
		fail = game.add.audio('fail');
		spawn = game.add.audio('spawn');

		game.stage.backgroundColor = "#DCDCDC";

		current_score_text = game.add.text(200, 400, '', { font: 'Arial', fontSize: '90px', fill: '#000', align: 'center' }); // 300, 500
		current_score_text.anchor.set(0.5, 0.5);
		current_best_text = game.add.text(200, 320, '', { font: 'Arial', fontSize: '30px', fill: '#000', align: 'center' });// 230, 450
		current_best_text.anchor.set(0.5, 0.5);
		current_best_score_text = game.add.text(200, 400, '', { font: 'Arial', fontSize: '90px', fill: 'blue', align: 'center' }); // 300, 500
		current_best_score_text.anchor.set(0.5, 0.5);

		hoop = game.add.sprite(88, 131, 'hoop');

		this.createCan();
		

		ai = game.add.sprite(200,200,'A');
        game.physics.arcade.enable(ai);
        //game.physics.p2.enable([ ai], false);
		ai.body.static = true;
		//ai.body.setCollisionGroup(collisionGroup);
		//ai.body.collides([slipper]);
        ai.body.velocity.x = 250;
        ai.anchor.setTo(0.5, 0.5);
        ai.body.movable  = true;
        ai.scale.set(1.0);
        ai.body.collideWorldBounds = true;
        this.createBall();
		
		cursors = game.input.keyboard.createCursorKeys();

		game.input.onDown.add(this.click, this);
		game.input.onUp.add(this.release, this);

		this.pauseButton = this.game.add.sprite(w/2, 40, 'pauseButton');
		this.pauseButton.anchor.set(0.5);
    	this.pauseButton.scale.x = 0.6;
    	this.pauseButton.scale.y = 0.6;
		this.pauseButton.inputEnabled = true;
		this.pauseButton.events.onInputUp.add(function () {
    	this.game.paused = true;
    	var style = {font:'30px Arial',fill : 'black'};
    	text = game.add.text(200, 270, "Click screen to Resume", style);
    	text.anchor.set(0.5, 0.5);
	}, this);
		game.input.onDown.add(function () {
    		if (this.game.paused) {
        	this.game.paused = false;
        	text.destroy();
    		}       
	}, this);
		labelhi = game.add.text(280, 25, "HI: " +this.getScore(),{font: '20px Arial', fill: '#black'});

	},

	update: function(){
		game.physics.arcade.enable(can);
		game.physics.arcade.overlap(ai,platform1,this.boundsNow);
		game.physics.arcade.overlap(ai,platform2,this.boundsNoww);


	if (slipper && slipper.body.velocity.y > 0) {
	
		slipper.body.collides([collisionGroup], this.hitRim, this);
	}
	var Wag = false;
	if (Wag) {
		if (slipper && slipper.body.velocity.y > 100 && slipper.body.y > 188 && !slipper.isBelowHoop) {
		slipper.isBelowHoop = true;
		slipper.body.collideWorldBounds = false;
		var rand = Math.floor(Math.random() * 3);
		emojiName = "lose" + rand;
			fail.play();
			if (puntos > this.getScore) {
				this.getScore = puntos;
			}
			puntos = 0;
			current_score_text.text = '';
			current_best_text.text = 'Current Best';
			current_best_score_text.text = +this.getScore();
		}
		emoji = game.add.sprite(200, 100, emojiName);
		emoji.scale.setTo(0.50, 0.50);
		emoji.anchor.setTo(0.5, 0.5);
		moveInTween = game.add.tween(emoji).from( { y: 150 }, 500, Phaser.Easing.Elastic.Out, true);
		fadeInTween = game.add.tween(emoji).from( { alpha: 0 }, 200, Phaser.Easing.Linear.None, true, 0, 0, false);
		moveInTween.onComplete.add(this.tweenOut, this);
	}

	if (slipper && slipper.body.y > 2000) {
		game.physics.p2.gravity.y = 0;
		
		slipper.kill();
		can.kill();
		ai.kill();
		this.createCan();
		
		ai = game.add.sprite(200,200,'A');
        game.physics.arcade.enable(ai);
        //game.physics.p2.enable([ ai], false);
		ai.body.static = true;
		//ai.body.setCollisionGroup(collisionGroup);
		//ai.body.collides([slipper]);
        ai.body.velocity.x = 250;
        ai.anchor.setTo(0.5, 0.5);
        ai.body.movable  = true;
        ai.scale.set(1.0);
        ai.body.collideWorldBounds = true;
        this.createBall();
		
	}
	
	if (slipper && slipper.body.velocity.y > 100 && slipper.body.y > 188 && !slipper.isBelowHoop) {
		slipper.isBelowHoop = true;
		slipper.body.collideWorldBounds = false;
		var rand = Math.floor(Math.random() * 3);
		if (slipper.body.x > 151 && slipper.body.x < 249) {
			emojiName = "win" + rand;
			can.animations.play('tulin');
			game.add.tween(can.scale).to({x : 0.3, y : 0.3}, 50, Phaser.Easing.Linear.None, true, 0, 0, false);
			if (end_location[1] < start_location[1]) {
					var slope = [end_location[0] - start_location[0], end_location[1] - start_location[1]];
					var x_traj = -600 * slope[0] / slope[1];
					this.launcher(x_traj);
				}
			puntos += 1;
			current_score_text.text = puntos;
			if (this.getScore()<=puntos){
				this.saveScore(puntos);
				labelhi.text = "HI: "+puntos;
	}
			score_sound.play();
		} else {

			emojiName = "lose" + rand;
			fail.play();
			if (puntos > this.getScore) {
				this.getScore = puntos;
			}
			puntos = 0;
			current_score_text.text = '';
			current_best_text.text = 'Current Best';
			current_best_score_text.text = +this.getScore();
		}
		emoji = game.add.sprite(200, 100, emojiName);
		emoji.scale.setTo(0.50, 0.50);
		emoji.anchor.setTo(0.5, 0.5);
		moveInTween = game.add.tween(emoji).from( { y: 150 }, 500, Phaser.Easing.Elastic.Out, true);
		fadeInTween = game.add.tween(emoji).from( { alpha: 0 }, 200, Phaser.Easing.Linear.None, true, 0, 0, false);
		moveInTween.onComplete.add(this.tweenOut, this);
	}

	if (slipper && slipper.body.y > 2000) {
		game.physics.p2.gravity.y = 0;
		
		slipper.kill();
		can.kill();
		ai.kill();
		this.createCan();
		
		ai = game.add.sprite(200,200,'A');
        game.physics.arcade.enable(ai);
        //game.physics.p2.enable([ ai], false);
		ai.body.static = true;
		//ai.body.setCollisionGroup(collisionGroup);
		//ai.body.collides([slipper]);
        ai.body.velocity.x = 250;
        ai.anchor.setTo(0.5, 0.5);
        ai.body.movable  = true;
        ai.scale.set(1.0);
        ai.body.collideWorldBounds = true;
        this.createBall();

	}

	},
		tweenOut: function() {
			moveOutTween = game.add.tween(emoji).to( { y: 50 }, 600, Phaser.Easing.Elastic.In, true);
			moveOutTween.onComplete.add(function() { emoji.kill(); }, this);
			setTimeout(function () {
				fadeOutTween = game.add.tween(emoji).to( { alpha: 0 }, 300, Phaser.Easing.Linear.None, true, 0, 0, false);
			}, 450);
		},

		hitRim: function() {

			backboard.play();
		},
		createCan: function() {
			can = game.add.sprite(200, 190, 'Lata');
			can.enableBody = true;
			can.scale.x = 0.5;
			can.scale.y = 0.5;
			can.anchor.set(0.5, 0.5);
			can.animations.add('tulin',[0,1,2,3,4,5,6,7],50,true);

		},
		createBall: function() {

			var xpos;
			if (puntos === 0) {
				xpos = 200;
			} else {
				xpos = 60 + Math.random() * 280;
			}
			spawn.play();
			slipper = game.add.sprite(xpos, 547, 'Slip');
			slipper.animations.add('roll',[0,1,2,3,4,5,6,7],30,true);
			game.add.tween(slipper.scale).from({x : 0.7, y : 0.7}, 100, Phaser.Easing.Linear.None, true, 0, 0, false);
			game.physics.p2.enable(slipper, false);
			slipper.body.setCircle(60);
			slipper.launched = false;
			slipper.isBelowHoop = false;
		},

		click:function(pointer) {

			var bodies = game.physics.p2.hitTest(pointer.position, [ slipper.body ]);
			if (bodies.length) {
				start_location = [pointer.x, pointer.y];
				isDown = true;
				location_interval = setInterval(function () {
					start_location = [pointer.x, pointer.y];
				}.bind(this), 200);
			}
		},

		release:function(pointer) {

			if (isDown) {
				window.clearInterval(location_interval);
				isDown = false;
				end_location = [pointer.x, pointer.y];

				if (end_location[1] < start_location[1]) {
					var slope = [end_location[0] - start_location[0], end_location[1] - start_location[1]];
					var x_traj = -400 * slope[0] / slope[1];
					this.launch(x_traj);
				}
			}
		},
		launcher:function(x_traj){
			can.body.velocity.x = x_traj;
			can.body.velocity.y = -100;
		},
		launch:function(x_traj) {

			if (slipper.launched === false) {
				slipper.body.setCircle(36);
				slipper.body.setCollisionGroup(collisionGroup);
				current_best_text.text = '';
				current_best_score_text.text = '';
				slipper.launched = true;
				slipper.animations.play('roll');
				game.physics.p2.gravity.y = 3000;
				game.add.tween(slipper.scale).to({x : 0.6, y : 0.6}, 500, Phaser.Easing.Linear.None, true, 0, 0, false);
				slipper.body.velocity.x = x_traj;
				slipper.body.velocity.y = -1750;
				slipper.body.rotateRight(x_traj / 3);
				whoosh.play();
			}
		},
		saveScore :function(score){
			localStorage.setItem("TumbangPresoGameData.com",score);
		},

		getScore :function(){
			return (localStorage.getItem("TumbangPresoGameData.com") == null || localStorage.getItem("TumbangPresoGameData.com") == "")?0:
			localStorage.getItem("TumbangPresoGameData.com");
		},
		boundsNow:function(){
		ai.body.velocity.x = 250;
		},
		boundsNoww:function(){
		ai.body.velocity.x = -250;
		},
		


};		

winGame = {
	preload:function(){

	},
	create:function(){

	},
	update:function(){

	}
	
}

loseGame = {
	preload:function(){

	},
	create:function(){

	},
	update:function(){

	}
	
}
