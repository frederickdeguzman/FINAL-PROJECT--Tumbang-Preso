var w = 400, h = 625;
var location_interval;
var isDown = false;
var start_location;
var end_location;
var hoop,
		left_rim,
		right_rim,
		slipper,
		can,
		front_rim,
		puntos = 0,
		current_score_text,
		high_score_text,
		current_best_text;

var score_sound,
		backboard,
		whoosh,
		fail,
		spawn;

var moveInTween,
		fadeInTween,
		moveOutTween,
		fadeOutTween,
		emoji,
		emojiName;
var collisionGroup;

var game = new Phaser.Game( w, h, Phaser.CANVAS, '');

game.state.add("bootGame", bootGame);
game.state.add("preloadGame", preloadGame);
game.state.add("menuGame", menuGame);
game.state.add("playGame", playGame);
game.state.add("winGame", playGame);
game.state.add("loseGame", loseGame);

game.state.start("bootGame");

